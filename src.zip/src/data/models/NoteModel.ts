

export interface NoteModel {
  id: string;
  title: string;
  content: string;
}
