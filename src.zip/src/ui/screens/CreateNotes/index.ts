import view from "./view";

export default view;
