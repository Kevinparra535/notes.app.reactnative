import PreLogin from "./view";

export default PreLogin;
