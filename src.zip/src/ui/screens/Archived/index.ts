import Archived from "./view";

export default Archived