import Login from "./view";

export default Login;
