import Notes from "./view";

export default Notes;
