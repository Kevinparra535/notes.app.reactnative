import PickAvatar from "./view";

export default PickAvatar;
