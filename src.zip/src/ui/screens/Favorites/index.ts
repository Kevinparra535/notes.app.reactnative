import FavoritesScreen from "./view";

export default FavoritesScreen