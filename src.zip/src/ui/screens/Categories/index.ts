import Categories from "./view";

export default Categories