import NotesDetails from "./view";

export default NotesDetails;
