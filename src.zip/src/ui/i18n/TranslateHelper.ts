import i18n from "./config";

export const TranslateHelper = (langkey: string) => {
  return i18n.t(langkey);
};
