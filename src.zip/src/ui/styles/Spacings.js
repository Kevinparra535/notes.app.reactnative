const Spacings = {
  space: 10,
  spacehalf: 5,
  spacex2: 20,
  spacex3: 30,
  spacex4: 40,
  spacex5: 50,
  spacex6: 60,
  spacex7: 70,
  spacex8: 80,
  spacex9: 90,
  spacex10: 100,
  spacex11: 110,
  spacex12: 120,
  spacex13: 130,
  spacex14: 140,
  spacex15: 150,
};

export default Spacings;
