import { NoteRepositoryImpl } from "@/data/repositories/NoteRepositoryImpl";
import Note from "@/domain/entities/Note";

export class GetNoteById {
  constructor(private _noteRepository: NoteRepositoryImpl) {}

  async execute(noteId: string) {
    const noteModel = await this._noteRepository.getNoteById(noteId);
    return new Note(noteModel); // transforma el modelo a una entidad
  }
}
