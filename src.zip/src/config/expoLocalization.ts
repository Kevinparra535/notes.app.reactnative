import * as Localization from 'expo-localization';

export default Localization;